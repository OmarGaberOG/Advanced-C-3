﻿namespace Assignment_3
{
    internal class Program
    {
        #region 1.	 implement a function to reverse the elements of a queue using a stack.Given a Queue,
        public static void ReverseQueueByStack(Queue<int> q)
        {
            Stack<int> stack = new Stack<int>(q);
            Console.Write("Queue :");
            foreach (int i in q)
                Console.Write(i + " ");
            Console.Write("=>");
            Console.Write(" Reversed Queue:");
            foreach (int i in stack)
                Console.Write(i + " ");
        }
        #endregion

        #region 2.	Given a Stack, implement a function to check if a string of parentheses is balanced using a stack.
        public static void ParenThesesCheck(string word)
        {
            Stack<char> stack = new Stack<char>();
            foreach (char c in word)
            {
                if (c == '{' || c == '[' || c == '(')
                {
                    stack.Push(c);
                }

                else if (c == '}' || c == ']' || c == ')')
                {
                    if (stack.Count == 0)
                    {
                        Console.WriteLine("Not Balanced!!");
                        return;
                    }
                    char check = stack.Pop();
                    if (c == '}' && check != '{' || c == ']' && check != '[' || c == ')' && check != '(')
                    {
                        Console.WriteLine("Not Balanced!!");
                        return;
                    }
                    else { Console.WriteLine("Balanced (^^)"); }
                }
            }
            if (stack.Count == 0)
            {
                Console.WriteLine("Balanced (^^)");
            }
            else
            {
                Console.WriteLine("Not Balanced!!");

            }
        } 
        #endregion
        static void Main(string[] args)
            {
            #region 1
            //Queue<int> q1 = new Queue<int>();
            //q1.Enqueue(4);
            //q1.Enqueue(3);
            //q1.Enqueue(2);
            //q1.Enqueue(1);
            //ReverseQueueByStack(q1); 
            #endregion

            #region 2
            //Console.Write("Enter word to check the balance:");
            //string word = Console.ReadLine();
            //ParenThesesCheck(word); 
            #endregion

        }
        
    }
}
